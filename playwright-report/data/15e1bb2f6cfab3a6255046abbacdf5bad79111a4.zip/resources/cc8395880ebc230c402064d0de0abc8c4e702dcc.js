(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_76dea0b2._.js",
  "static/chunks/_d0a0d0cf._.js"
],
    source: "dynamic"
});
