(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8dabb58b._.css",
  "static/chunks/node_modules_d8eb4cba._.js",
  "static/chunks/_37c015e1._.js"
],
    source: "dynamic"
});
