(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_4f74b3dc._.js",
  "static/chunks/node_modules_2c14f28f._.js"
],
    source: "dynamic"
});
